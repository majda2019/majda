package com.example.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class chien extends AppCompatActivity {
    MediaPlayer mySong;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chien);
        mySong = MediaPlayer.create(chien.this, R.raw.chien);
    }
    public void playIT(View v) {
        mySong.start();

    }

    @Override
    protected void onPause() {
        super.onPause();
        mySong.release();
    }
    public void next(View v){
        Intent i = new Intent(chien.this,lion.class);
        startActivity(i);
    }
    public void pre(View v){
        Intent i = new Intent(chien.this,chat.class);
        startActivity(i);


    }

}
