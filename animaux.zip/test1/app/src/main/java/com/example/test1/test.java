package com.example.test1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class test extends AppCompatActivity {
    private  TextView coutlabel;
    ImageView questionImage;
    private Button rep1;
    private Button rep2;
    private Button rep3;
    private Button rep4;


    private String reponsejuste;
    private  int reponsejusteCount =0;
    private  int quizCount =1;
    static final private int QUIZ_COUNT = 8;
    ArrayList<ArrayList<String>> quizArray = new ArrayList<>();

    String quizData[][]={

        {"chat","chat","mouton","chien","lion"},
         {"chien","chien","mouton","chat","vache"},
        {"eleph","elephant","mouton","chien","lion"},
    {"lion","lion","mouton","chien","singe"},
    {"mouton","mouton","vache","chien","lion"},
        {"poule","poule","chat","chien","elephant"},
    {"singe","singe","mouton","chien","lion"},
    {"vache","vache","chat","elephant","lion"}

};





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        coutlabel =(TextView)findViewById(R.id.coutlabel);
        questionImage= findViewById(R.id.questionImage);
        rep1=(Button)findViewById(R.id.rep1);
        rep2=(Button)findViewById(R.id.rep2);
        rep3=(Button)findViewById(R.id.rep3);
        rep4=(Button)findViewById(R.id.rep4);


        for(int i =0;i< quizData.length; i++){
            ArrayList<String> tempArray = new ArrayList<>();
            tempArray.add(quizData[i][0]);
            tempArray.add(quizData[i][1]);
            tempArray.add(quizData[i][2]);
            tempArray.add(quizData[i][3]);
            tempArray.add(quizData[i][4]);

            quizArray.add(tempArray);
        }

     showNextQuiz();
    }

    public void showNextQuiz(){

        coutlabel.setText("Q"+quizCount);
        Random random = new Random();
        int randomNum= random.nextInt(quizArray.size());


        ArrayList<String> quiz = quizArray.get(randomNum);
        questionImage.setImageResource(getResources().getIdentifier(quiz.get(0),"drawable",getPackageName()));
        reponsejuste = quiz.get(1);

        quiz.remove(0);
        Collections.shuffle(quiz);

        rep1.setText(quiz.get(0));
        rep2.setText(quiz.get(1));
        rep3.setText(quiz.get(2));
        rep4.setText(quiz.get(3));
        quizArray.remove(randomNum);

    }
    public  void checkAnswer(View view){

        Button answerBtn = (Button)findViewById(view.getId());
        String btnText =answerBtn.getText().toString();
String alertTitle;
        if(btnText.equals(reponsejuste)){
          alertTitle="bravoooooo !!!!";
            reponsejusteCount++;
        }
        else alertTitle = "oooooooooh ! faux";

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(alertTitle);
        builder.setMessage("la réponse est :"+reponsejuste);
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {

                if(quizCount==QUIZ_COUNT){
                    //showReslut();
                    Intent intent = new Intent(getApplicationContext(),result.class);
                    intent.putExtra("RIGHT_ANSWER_COUNT",reponsejusteCount);
                    startActivity(intent);

                }else{
                    quizCount++;
                    showNextQuiz();
                }

            }
        });
        builder.setCancelable(false);
        builder.show();
    }



    }
