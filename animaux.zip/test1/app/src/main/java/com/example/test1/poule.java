package com.example.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class poule extends AppCompatActivity {
    MediaPlayer mySong;
    Button btn ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poule);
        mySong = MediaPlayer.create(poule.this, R.raw.la_poule);
    }
    public void playIT(View v) {
        mySong.start();

    }

    @Override
    protected void onPause() {
        super.onPause();
        mySong.release();
    }
    public void next(View v){
        Intent i = new Intent(poule.this, elephant.class);
        startActivity(i);


    }
    public void pre(View v){
        Intent i = new Intent(poule.this,mouton.class);
        startActivity(i);
    }

}
