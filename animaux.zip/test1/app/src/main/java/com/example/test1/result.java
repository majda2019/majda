package com.example.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ShareActionProvider;
import android.widget.TextView;

public class result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        TextView resultLabel =(TextView) findViewById(R.id.resultlabel);

         int score =getIntent().getIntExtra("RIGHT_ANSWER_COUNT",0);

        SharedPreferences settings = getSharedPreferences("quiz", Context.MODE_PRIVATE);
        int totalScore = settings.getInt("totalScore",0);
        totalScore+= score;

        resultLabel.setText(score+"/8");

         SharedPreferences.Editor editor = settings.edit();
         editor.putInt("totalScore",totalScore);
         editor.commit();
    }
    public void retour(View v){
        Intent i = new Intent(result.this,test.class);
        startActivity(i);


    }
    public void next(View v){
        Intent i = new Intent(result.this,acceuil.class);
        startActivity(i);
    }
}
