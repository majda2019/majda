package com.example.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

public class vache extends AppCompatActivity {
    MediaPlayer mySong;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vache);
        mySong = MediaPlayer.create(vache.this, R.raw.vache);
    }
    public void playIT(View v) {
        mySong.start();

    }

    @Override
    protected void onPause() {
        super.onPause();
        mySong.release();
    }
    public void pre(View v){
        Intent i = new Intent(vache.this, elephant.class);
        startActivity(i);


    }
    public void start(View v){
        Intent i = new Intent(vache.this,finaprrenti.class);
        startActivity(i);


    }

}
