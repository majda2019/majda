package com.example.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class mouton extends AppCompatActivity {
    MediaPlayer mySong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mouton);
        mySong = MediaPlayer.create(mouton.this, R.raw.mouton);
    }
    public void playIT(View v) {
        mySong.start();

    }

    @Override
    protected void onPause() {
        super.onPause();
        mySong.release();
    }
    public void next(View v){
        Intent i = new Intent(mouton.this,poule.class);
        startActivity(i);

    }
    public void pre(View v){
        Intent i = new Intent(mouton.this,lion.class);
        startActivity(i);


    }

}
